<?php
require "userdash.php";
?>

<?php
$obj->select_hos();

?>

<?php

if(isset($_SESSION['auth']))
{
   if($_SESSION['user_type'] == 2)
   {
    header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
   // header("location:userdash.php");
   //echo $_SESSION['disease_name'];
  // echo $_SESSION['hospital_name'];
   }
}
else
{
    header("location:login.php");
}

?>


<html>

<head></head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3" style="min-height:500px"></div>
            
            <div class="col-md-6" style="min-height:500px;border:2px solid black">

            <h2 style="text-align:center;font-weight:bold">Appointment Form</h2>

            <form  method="post" action="" enctype="multipart/form-data" autocomplete="off"  id="sign">
						
						

						<div class="form-group">
							<label for="email">Firstname</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="text" class="form-control" value="<?php echo $_SESSION['first_name'] ?>" name="first_name" placeholder=""/>
								</div>
                            </div>

						<div class="form-group">
							<label for="mobile">Lastname</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									<input type="text" class="form-control" value="<?php echo $_SESSION['last_name'] ?>" name="last_name" placeholder=""/>
								</div>
						</div>

						<div class="form-group">
							<label for="address">Email</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
									
                                    <input type="text" class="form-control" value="<?php echo $_SESSION['email'] ?>" name="email" placeholder=""/>
								</div>
						</div>


                       
                        <div class="form-group">
							<label for="name">Mobile</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="tel" class="form-control" name="mobile" value="<?php echo $_SESSION['mobile'] ?>" id="mobile"  placeholder=""/>
							</div>
						</div>

                        <div class="form-group">
							<label for="name">Address</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<textarea name="address" class="form-control" id="address"><?php echo $_SESSION['address'] ?></textarea>
							</div>
						</div>


                        <div class="form-group">
							<label for="name">Appointment Date</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="" aria-hidden="true"></i></span>
				<input type="datetime-local" class="form-control" name="appointment_date" id="appointment_date"  placeholder=""/>
							</div>
						</div>

                        
                        <br>



				<button type="submit" class="btn btn-success">SUBMIT</button>
						
					</form>
            </div>
            <div class="col-md-3"  style="min-height:500px;"></div>
        </div>
    </div>
</body>

</html>