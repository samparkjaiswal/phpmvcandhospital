$(function(){
    var $disregister = $("#dis");
    $.validator.addMethod("noSpace", function(value, element){   //only for white space validation
        return value == "" || value.trim().length !=0
        }, "Spaces are not allowed");
    if($disregister.length)
    {
        $disregister.validate({
            rules:{
                disease_name:{
                    required: true,
                    //nowhitespace: true,
                  //  lettersonly: true,
                   noSpace: true//if add method use then this property call
                },
                disease_symptoms:{
                    required: true,
                   // nowhitespace: true,
                    //lettersonly: true
                    noSpace: true
                }
                
            },
            
            messages:{
                disease_name:{
                    required: "Please enter diseasename!"
                },
                disease_symptoms:{
                    required: "Please describe disease symptoms!"
                }
               
                

            }
        })
    }
})