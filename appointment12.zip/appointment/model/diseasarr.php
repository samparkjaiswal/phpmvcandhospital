<?php

require "model.php";

$dis=array(
    'disease_name'=>$_POST['disease_name'],
    'disease_symptoms'=>$_POST['disease_symptoms'],
    'disid'=>$_POST['disid']
);

$obj->adddiseas($dis);
?>