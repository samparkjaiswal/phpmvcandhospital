<!-- View -->
<!-- Listing Page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listing Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<body>
<!-- Basic Details -->
<table class=" table table-primary table-striped">
  <thead>
    <tr class="table-info">
    <th colspan="7" style="font-size: 30px; text-align: center;">Basic Details</th>
    <th colspan="4" style="font-size: 30px; text-align: center;">Personal Details</th>
    <th colspan="7" style="font-size: 30px; text-align: center;">Subjects</th></tr>
    <tr class="table-primary">
      <th scope="col">Student ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">E-mail</th>
      <th scope="col">Username</th>
      <th scope="col">Class</th>
      <th scope="col">Section</th>
      <th scope="col">Father Name</th>
      <th scope="col">Mother Name</th>
      <th scope="col">Address</th>
      <th scope="col">Phone Number</th>
      <th scope="col">Math</th>
      <th scope="col">Hindi</th>
      <th scope="col">Science</th>
      <th scope="col">Social Studies</th>
      <th scope="col">French</th>
      <th scope="col">German</th>
      <th scope="col">English</th>
    </tr>
  </thead>
  <?php
   print <<< HTML
   
   
   <tbody class="table-group-divider">
    <tr class="table-primary">
      <th scope="row"></th> <!-- Student ID-->
      <td></td> <!-- First Name-->
      <td></td> <!-- Last Name-->
      <td></td> <!-- E-mail-->
      <td></td> <!-- Username-->
      <td></td> <!-- Class-->
      <td></td> <!-- Section-->
      <td></td> <!-- Father Name-->
      <td></td> <!-- Mother Name-->
      <td></td> <!-- Address-->
      <td></td> <!-- Phone Number-->
      <td></td> <!-- Math-->
      <td></td> <!-- Hindi-->
      <td></td> <!-- Science-->
      <td></td> <!-- Social Studies-->
      <td></td> <!-- French-->
      <td></td> <!-- German-->
      <td></td> <!-- English-->
    </tr>
  </tbody>
  HTML;
  ?>
</table>
</body>
</html>