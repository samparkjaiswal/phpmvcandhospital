<!-- Insert PHP -->

<?php

require 'model.php';

$arr;
$arr[0] = $_POST['first_name'];
$arr[1] = $_POST['last_name'];
$arr[2] = $_POST['stu_email'];
$arr[3] = $_POST['username'];   
$arr[4] = $_POST['passkey'];
$arr[5] = $_POST['con_passkey'];
$arr[6] = $_POST['class'];
$arr[7] = $_POST['section'];
$arr[8] = $_POST['father_name'];
$arr[9] = $_POST['mother_name'];
$arr[10] = $_POST['address'];
$arr[11] = $_POST['phone_number'];
$arr[12] = $_POST['checkbx_subject1'];
$arr[13] = $_POST['checkbx_subject2'];
$arr[14] = $_POST['checkbx_subject3'];
$arr[15] = $_POST['checkbx_subject4'];
$arr[16] = $_POST['checkbx_subject5'];
$arr[17] = $_POST['checkbx_subject6'];
$arr[18] = $_POST['checkbx_subject7'];


$objmodel->insert_data($arr);
?>
