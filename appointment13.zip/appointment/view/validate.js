





$().ready(function(){
    $("#frm").validate
    ({
        rules:
        {
            first_name:
            {
            required:true
            
            }
             
           

        },
            
         messages:
         {
                first_name:
                {
                    required: "Please enter your firsyname"
                }
                
           }
            

             
    });
});
