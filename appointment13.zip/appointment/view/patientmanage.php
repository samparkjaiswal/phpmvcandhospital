<?php
include "dash.php";
//require '../model/model.php';

?>

<?php

if(isset($_SESSION['auth']))
{
  
   if($_SESSION['user_type'] == 2)
   {
    
    //header("location:dash.php");
   }
   elseif($_SESSION['user_type'] == 1)
   {
    header("location:userdash.php");
   }
}
else
{
  header("location:login.php");
}

?>


<html>
    <head>
    <h2 style="text-align:center;color:red;margin-top:50px;font-weight:900"><u>Patient Record</u></h2>
<!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />-->
</head>
<body>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>Contact</th>
<th>Address</th>

</tr>

<?php

$rec=$obj->select_patient();

foreach($rec as $value)
{
    echo "
    <tr style='text-align:center'>
    <td>".$value['id']."</td>
    <td>".$value['first_name']."</td>
    <td>".$value['last_name']."</td>
    <td>".$value['email']."</td>
    <td>".$value['mobile']."</td>
    <td>".$value['address']."</td>
    
    
    
    </tr>
    ";
}

?>

</table>
</center>
</body>
</html>