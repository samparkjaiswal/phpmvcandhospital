<?php

require "model.php";

$obj->user_logout();

?>