<?php
require "model.php";

$rec=array(
    'email'=>$_POST['email'],
    'password'=>$_POST['password']
);

$obj->login($rec);

?>