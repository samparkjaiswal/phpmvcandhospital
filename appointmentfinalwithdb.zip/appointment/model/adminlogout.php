<?php

require "model.php";


$obj->logout();

?>