<?php

require "model.php";

$data=array(

    'first_name'=>$_POST['first_name'],
    'last_name'=>$_POST['last_name'],
    'email'=>$_POST['email'],
    'password'=>$_POST['password'],
    'mobile'=>$_POST['mobile'],
    'address'=>$_POST['address'],
);
$obj->insert_data($data);
?>