<html>
    <head>

<!--
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<!------ Include the above in your HEAD tag ---------->


<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!------ Include the above in your HEAD tag ---------->

<style>
.main{
 	padding: 40px 0;
}
.main input,
.main input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

    </style>
</head>

<body>
	<div class="container">
			<div class="main">
				<div class="main-center">
				<h5>Sign Up For New Hospital.</h5>

					<form  method="post" action="../model/hoinsert.php" enctype="multipart/form-data" autocomplete="off">
						
						<div class="form-group">
							<label for="name">Hospital Name</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-hospital-o fa" aria-hidden="true"></i></span>
				<input type="text" class="form-control" name="hospital_name" id="name"  placeholder="Enter Hospital Name"/>
							</div>
						</div>

						<div class="form-group">
							<label for="department">Department</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-building fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="department" placeholder="Enter Department"/>
                                    
							</div>
						</div>

						<div class="form-group">
							<label for="email">Email</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="email" class="form-control" name="email" placeholder="Enter Email"/>
								</div>
                            </div>

						<div class="form-group">
							<label for="mobile">Mobile</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-phone fa-lg" aria-hidden="true"></i></span>
									<input type="tel" class="form-control" name="mobile" placeholder="Enter Contact"/>
								</div>
						</div>

						<div class="form-group">
							<label for="address">Address</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-address-card fa-lg" aria-hidden="true"></i></span>
									
                                    <textarea name="address" class="form-control" placeholder="Enter Hospital Address"></textarea>
								</div>
						</div>


                        <div class="form-group">
							<label for="file">Hospital Image Upload</label>
								<div class="">
									
									<input type="file" class="form-control" name="file" placeholder=""/>
                                    
								</div>
						</div>



				<button type="submit" class="btn btn-success">SUBMIT</button>
						
					</form>

				</div><!--main-center"-->
			</div><!--main-->
		</div><!--container-->

</body>
</html>