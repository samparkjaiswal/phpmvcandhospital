$(function(){
    var $appointment = $("#appointment");
   $.validator.addMethod("noSpace", function(value, element){   //only for white space validation
    return value == "" || value.trim().length !=0
    }, "Spaces are not allowed");
    if($appointment.length)
    {
        $appointment.validate({
            rules:{
                first_name:{
                    required: true,
                    noSpace: true//if add method use then this property call
                   },
                   last_name:{
                    required: true,
                    noSpace: true
                
                },
                email:{
                    required: true,
                    email: true,
                    noSpace: true
                },
                mobile:{
                    required: true,
                    minlength: 10,
                    maxlength: 12,
                  //  nowhitespace: true,
                    digits:true,
                   noSpace: true
                   
                   
                },
                address:{
                    required: true,
                  //  nowhitespace: true,
                    //lettersonly: true
                    noSpace: true
                },
                appointment_date:{
                    required: true
                }
               
            },
            
            messages:{
                first_name:{
                    required: "Please enter firstname!"
                },
                last_name:{
                    required: "Please enter lastname!"
                },
                email:{
                    required: "Please enter email!",
                    email: "Please enter valid email!"
                },
                mobile:{
                    required: "Please enter phone number!",
                    minlength: "Please enter atleast 10 charecter!",
                    maxlength: "Number not be greater than 12 digit!"
                },
                address:{
                    required: "Please enter address!"
                },
                appointment_date:{
                    required: "Please choose appointment date & time!"
                }
                

            }
        })
    }
})