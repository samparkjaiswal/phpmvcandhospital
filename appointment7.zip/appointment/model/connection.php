<?php

//making a class
class dbconnect 
{
   //declare property/variable with access modifier
    private $server="localhost";
    private $user="root";
    private $password="";
    private $dbname="hospital";
    public $conn;


//declare a consturctor method which autocall when we make object 
    public function __construct()
    {
        
        //in this method we establish database connection and store in a variable

        $this->conn=new mysqli($this->server,$this->user,$this->password,$this->dbname);
        if(!$this->conn)
        {
            echo "connection failed";
            die($this->conn->error);
        }
        else
        {
              //echo "Connection Successfull";
        }
    }
}

//there we call the object for checking connection
//$obj=new dbconnect();


?>