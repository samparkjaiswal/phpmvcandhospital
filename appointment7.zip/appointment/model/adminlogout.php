<?php

require "model.php";


$obj->admin_logout();

?>