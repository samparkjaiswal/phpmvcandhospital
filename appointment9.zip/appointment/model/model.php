<?php
session_start();

require "connection.php";
//class dbmodel inherit the dbname class (which is define in connection.php file)
class dbmodel extends dbconnect 
{
    public function insert_data($data)
    {
        $sql_ins_p="insert into patient(first_name,last_name,email,password,mobile,address) values('$data[first_name]','$data[last_name]','$data[email]','$data[password]','$data[mobile]','$data[address]')";

        $result_p=$this->conn->query($sql_ins_p);
        if(!$result_p)
        {
            echo "<script>alert('Registration Failed');window.location.href='../view/patientreg.php'</script>";
            die($this->conn->error);
        }
        else{
           echo "<script>alert('Registration Successfull');window.location.href='../view/patientreg.php'</script>";
        }
    }


    public function select_patient()
    {
        $sql_sel_p="select * from patient";
        $result_sel=$this->conn->query($sql_sel_p);
        if($result_sel->num_rows>0)
        {
            while($row=$result_sel->fetch_assoc())
            {
                $data[]=$row;
            }
            return $data;
        }
    
    }


    public function login($rec)
    {
        
        $sql_login="select email,password,user_type from patient where email='$rec[email]' and password='$rec[password]'";
        $result_log=$this->conn->query($sql_login);
        
        if($result_log->num_rows>0)
        {
            
            $row=$result_log->fetch_assoc();
            
            $_SESSION['auth']='$rec[email]';
              //print_r($row['user_type']);
           
          
           if($row['user_type']==2)
           {
            
            echo "<script>alert('Welcome To Admin Zone');window.location.href='../view/dash.php'</script>";
           // echo "login";
           }
           else
           {
            echo "<script>alert('Welcome To User Zone');window.location.href='../view/diseasedisplay.php'</script>";
           }
            
        }
        else
        {
            echo "<script>alert('Wrong Email/Password');window.location.href='../view/login.php'</script>";
        }
    }

    public function admin_logout()
    {
        
        session_unset();
        session_destroy();
        header("location:../view/login.php");
    }

    public function user_logout()
    {
        
        session_unset();
        session_destroy();
        header("location:../view/login.php");
    }




    public function hoinsert_data($hos)
    {
        $img=$_FILES['file']['name'];
       // print_r($img);
        //send in database only image name not location because 1st we pass image name after that send it folder
        if(file_exists("../view/upload/".$_FILES['file']['name']))
        {
            echo "<script>alert('Image Already Upload');window.location.href='../view/hospitalmanage.php'</script>";
        }
        else
        {
        
         $sql_hoinsert="insert into hospi(hospital_name,department,email,mobile,address,file,hosid) values('$hos[hospital_name]','$hos[department]','$hos[email]','$hos[mobile]','$hos[address]','$img','$hos[hosid]')";
            $res_hos=$this->conn->query($sql_hoinsert);
            if($res_hos)
            {
                
                move_uploaded_file($_FILES["file"]["tmp_name"], "../view/upload/".$_FILES['file']['name']);
               echo "<script>alert('Hospital Inserted');window.location.href='../view/hospitalmanage.php'</script>";
            }
            else{
                echo "<script>alert('Failed');window.location.href='../view/hospitalmanage.php'</script>";
                die($this->conn->error);
            }
        }
    }


   



    public function houpdisplay_data()
    {
        if(isset($_GET['eid']))
        {
            $id=$_GET['eid'];
            
            $sql_sel_hos="select * from hospi where id='$id'";
            $res_dis_hos=$this->conn->query($sql_sel_hos);
            if($res_dis_hos->num_rows>0)
            {
                $row_upd=$res_dis_hos->fetch_assoc();
                return $row_upd;
            }
        }
    }

    public function houpdate_data($data)
    {
       $new_file=$_FILES['file']['name'];
        $oldimage=$_POST['old_file'];

        if($new_file!='')
        {
            $update_filename=$_FILES['file']['name'];
        }
        else
        {
            $update_filename=$oldimage;
        }

//this function show an error at not choose image
     //   if(file_exists("../view/upload/".$_FILES['file']['name']))
      //  {
    //        echo "<script>alert('Image Already Upload');window.location.href='../view/hospitaldisplay.php'</script>";
    //    }
     //   else
      //  {
            $update_query="update hospi set hospital_name='$data[hospital_name]',department='$data[department]',email='$data[email]',mobile='$data[mobile]',address='$data[address]',file='$update_filename' where id='$data[editid]'";
            $res_upd_hos=$this->conn->query($update_query);
            if($res_upd_hos)
            {
               if($_FILES['file']['name']!='')
               {
                unlink("../view/upload/".$_POST['old_file']);
                move_uploaded_file($_FILES["file"]["tmp_name"], "../view/upload/".$_FILES['file']['name']);
                
                echo "<script>alert('Data updated');window.location.href='../view/hospitalmanage.php'</script>";
               }
               else
               {
                 echo "<script>alert('Data updated with old image');window.location.href='../view/hospitalmanage.php'</script>";
               }
            }
            else
            {
                 echo "<script>alert('Data Not Update');window.location.href='../view/hospitalmanage.php'</script>";
            }
             
        // }


    }




    public function select_hospital()
    {
        $sql_sel_h="select * from hospi";
        $result_sel_h=$this->conn->query($sql_sel_h);
        if($result_sel_h->num_rows>0)
        {
            while($row=$result_sel_h->fetch_assoc())
            {
                $data[]=$row;
            }
            return $data;
        }
    
    }


    public function delete_hostpital()
    {
      if(isset($_GET['id']))
      {
        $id=$_GET['id'];

        $sql_sel_ho="select * from hospi where id='$id'";
        $result_sel_ho=$this->conn->query($sql_sel_ho);
        $rew=$result_sel_ho->fetch_assoc();
        //print_r($rew['file']);

      $sql_del_h="delete from hospi where id='$id'";
        $result_del_h=$this->conn->query($sql_del_h);
       if($result_del_h)
       {
           unlink("../view/upload/".$rew['file']);
           //echo "Record Deleted";
           header("location:../view/hospitalmanage.php");
        }
        else{
            echo "<script>alert('Record Not Deleted');window.location.href='../view/hospitalmanage.php'</script>";
            die($this->conn->error);
        }
     }
    }


    public function adddiseas($dis)
    {
        $sql_ins_dis="insert into diseas(disease_name,disease_symptoms,disid) values('$dis[disease_name]','$dis[disease_symptoms]','$dis[disid]')";

        $result_dis=$this->conn->query($sql_ins_dis);
        if(!$result_dis)
        {
            echo "<script>alert('Disease not add');window.location.href='../view/diseasemanage.php'</script>";
            die($this->conn->error);
        }
        else{
           
            echo "<script>alert('Disease add');window.location.href='../view/diseasemanage.php'</script>";
        }
       
    }




   




    public function select_diseas()
    {
        $sql_sel_dis="select * from diseas";
        $result_dis=$this->conn->query($sql_sel_dis);
        if($result_dis->num_rows>0)
        {
            while($row=$result_dis->fetch_assoc())
            {
                $data[]=$row;
            }
            return $data;
        }
    
    }


    





}

$obj=new dbmodel();

//call the fuction for delete data
$obj->delete_hostpital();
?>