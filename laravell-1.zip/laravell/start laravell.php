//start the laravell
http://localhost:8000/ 
or http://127.0.0.1:8000/