<?php

require "../model/model.php";

?>



<html>
    <head>
    <h2 style="text-align:center;color:red"><u>Hospital Record</u></h2>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Hospitalname</th>
<th>Department</th>
<th>Email</th>
<th>Contact</th>
<th>Address</th>
<th>Image</th>
<th colspan="2">Operation</th>


</tr>

<?php

$rec=$obj->select_hospital();
/*
foreach($rec as $value)
{
   
   ?>
   <tr>
    <td><?php echo $value['id'];?></td>
    <td><?php echo $value['hospital_name'];?></td>
    <td><?php echo $value['department'];?></td>
    <td><?php echo $value['email'];?></td>
    <td><?php echo $value['mobile'];?></td>
    <td><?php echo $value['address'];?></td>
    <td><img src="<?php echo 'upload/'.$value['file'];?>" height="100px" width="100px" /></td>
</tr>
    
    
   <?php
}*/
//for image display this way so use concate
   foreach($rec as $value)
   {
    echo "
    <tr style='text-align:center'>
    <td>".$value['id']."</td>
    <td>".$value['hospital_name']."</td>
    <td>".$value['department']."</td>   
    <td>".$value['email']."</td>
    <td>".$value['mobile']."</td>
    <td>".$value['address']."</td>
    <td><img src=".'upload/'.$value['file']." height='70' width='70'></td>
    <td><a href='hoedit.php?eid=$value[id]'><button class='btn btn-warning'>Edit</button></a></td>
    <td><a href='../model/model.php?id=$value[id]'><button class='btn btn-danger'>Delete</button></a></td>

    </tr>";
   }



?>

</table>
</center>
</body>
</html>