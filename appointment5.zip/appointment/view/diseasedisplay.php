<?php

require "../model/model.php";

?>
<?php

//session_start();
if(!isset($_SESSION['auth']))
{
    header("location:login.php");
}

?>



<html>
    <head>
    <h2 style="text-align:center;color:red"><u>Disease Record</u></h2>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
    <center>
    
    <table class="table table-responsive" border="2px solid black" style="text-align:center">
<tr>

<th>Id</th>
<th>Disease Name</th>
<th>Disease Symptoms</th>
<th>Choose Disease</th>



</tr>

<?php

$rec=$obj->select_diseas();

   foreach($rec as $value)
   {
    echo "
    <tr style='text-align:center'>
    
    <td>".$value['id']."</td>
    <td>".$value['disease_name']."</td>
    <td>".$value['disease_symptoms']."</td>   
    <td><a><input type='checkbox' name='' /></a></td>
   

    </tr>";
   }



?>

</table>
</center>
<a href="../model/logout.php" style="margin-left:20px;"><button class="btn btn-danger">Logout</button></a>
</body>
</html>