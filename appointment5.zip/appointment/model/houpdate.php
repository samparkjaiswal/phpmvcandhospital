<?php

require "model.php";
$data=array(
    'editid'=>$_POST['hid'],
    'hospital_name'=>$_POST['hospital_name'],
    'department'=>$_POST['department'],
    'email'=>$_POST['email'],
    'mobile'=>$_POST['mobile'],
    'address'=>$_POST['address'],
);
$obj->houpdate_data($data);

?>