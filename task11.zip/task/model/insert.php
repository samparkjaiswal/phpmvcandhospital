<?php

//if we want to send data as array formate

$arr;

$arr;
$arr["first_name"]=$_POST['fname'];
$arr["last_name"]=$_POST['lname'];
$arr["email"]=$_POST['email'];
$arr["user_name"]=$_POST['uname'];
$arr["password"]=$_POST['pass'];
$arr["class"]=$_POST['class'];
$arr["section"]=$_POST['section'];
$arr["father_name"]=$_POST['faname'];
$arr["mother_name"]=$_POST['maname'];
$arr["address"]=$_POST['address'];
$arr["phone"]=$_POST['phone'];
$arr["language"]=$_POST['lanugage'];

?>


SELECT b.id, b.fname, b.lname, b.email, b.uname, b.class, b.section, p.faname, p.maname, p.address, p.phone, s.subject FROM ((basic AS b INNER JOIN personal AS p ON b.id = p.std_id) INNER JOIN subject AS s ON b.id = s.std_id);
