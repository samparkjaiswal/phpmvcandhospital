<?php
//require "model.php";
class dbconnected 
{
    //properties
    private $server='localhost';
    private $username='root';
    private $passkey='';
    private $dbbase='task3';
    public $conn_var;

    //methods
    public function __construct()
    {
        $this->conn_var=new mysqli($this->server,$this->username,$this->passkey,$this->dbbase);
        if(!$this->conn_var)
        {
            echo "Connection Failed";
            die($this->conn_var->error);
        }
        else
        {
           // echo "Connection Successfull";
        }
        
    }
}
//$obj=new dbconnected();
?>