<?php
include "code/connection.php";

$obj=new Database();
?>